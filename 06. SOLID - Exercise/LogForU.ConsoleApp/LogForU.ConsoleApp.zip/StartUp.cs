﻿using LogForU.ConsoleApp.Core;
using LogForU.ConsoleApp.Core.Interfaces;

IEngine engine = new Engine();

engine.Run();