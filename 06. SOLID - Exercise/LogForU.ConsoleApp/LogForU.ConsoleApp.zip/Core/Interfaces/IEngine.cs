﻿namespace LogForU.ConsoleApp.Core.Interfaces;

public interface IEngine
{
    void Run();
}