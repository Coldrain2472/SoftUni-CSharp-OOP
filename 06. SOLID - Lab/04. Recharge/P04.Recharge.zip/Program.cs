﻿namespace P04.Recharge
{
    class Program
    {
        static void Main()
        {
        }
    }
}
