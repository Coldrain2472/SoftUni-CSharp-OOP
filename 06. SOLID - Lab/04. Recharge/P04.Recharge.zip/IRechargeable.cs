﻿namespace P04.Recharge
{
    public interface IRechargeable
    {
        void Recharge();
    }
}
