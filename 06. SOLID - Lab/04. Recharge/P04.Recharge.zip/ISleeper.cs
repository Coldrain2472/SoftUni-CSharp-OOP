﻿namespace P04.Recharge
{
    public interface ISleeper
    {
        void Sleep();
    }
}
