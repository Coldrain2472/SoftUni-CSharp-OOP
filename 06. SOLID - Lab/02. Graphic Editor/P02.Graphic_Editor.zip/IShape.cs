﻿using System;

namespace P02.Graphic_Editor
{
    public interface IShape
    {
        string GetShape();
    }
}
