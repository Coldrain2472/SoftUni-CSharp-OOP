﻿namespace P02.Graphic_Editor
{
    public class Circle : IShape
    {
        public string GetShape()
        {
            return "I'm circle";
        }
    }
}
