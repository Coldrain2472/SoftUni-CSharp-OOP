﻿using System;

namespace P02.Graphic_Editor
{
    public class Square : IShape
    {
        public string GetShape()
        {
            return "I'm square";
        }
    }
}
