﻿namespace HighwayToPeak.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
